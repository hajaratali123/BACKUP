// rent.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const rentSchema = new Schema({
    startDate: {
        type: Date,
        required: true,
    },
    endDate: {
        type: Date,
        required: true,
    },
    listing: {  // Update the field name to 'listing'
        type: Schema.Types.ObjectId,
        ref: "Listing", // Reference the Listing model
      },
   
});

const Rent = mongoose.model('Rent', rentSchema);
module.exports = Rent;
