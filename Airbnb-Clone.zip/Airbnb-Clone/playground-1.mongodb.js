
use('test');

// db.listings.find({})
// db.menus.find({})
// db.rents.find({})
// db.reviews.find({})

  
//   db.reviews.find({
//     "author": ObjectId("65abff46d1f18d4f5b577ae6")
//   });
  


//   db.listings.aggregate([
//   {
//     $lookup: {
//       from: 'reviews',
//       localField: '_id',
//       foreignField: 'listings_id',
//       as: 'reviews'
//     }
//   },
//   {
//     $group: {
//       _id: {
//         id: '$id',
//         title: '$title',
//         owner: '$owner'
//       },
//       average_rating: { $avg: '$reviews.rating' }
//     }
//   },
//   {
//     $sort: {
    
//       average_rating: -1
//     }
//   },
//   {
//     $limit: 1
//   },
//   {
//     $project: {
//       _id: 0,
//       title: '$_id.title',
//       owner: '$_id.owner',
//       average_rating: 1
//     }
//   }
// ]);

// db.listings.aggregate([
//     {
//       $lookup: {
//         from: 'reviews',
//         localField: '_id',
//         foreignField: 'listings_id',
//         as: 'reviews'
//       }
//     },
//     {
//       $project: {
      
//         reviews: 1  // Include the reviews field to inspect the data
//       }
//     }
//   ]);
  



// db.reviews.find({ listing_id: '65acade278423df6c11a78d8' });



var listingIdToFetch = ObjectId("65acade278423df6c11a78d8"); // Replace with the ID of the listing to fetch comments for

db.listings.aggregate([
  {
    $match: { _id: listingIdToFetch }
  },
  {
    $lookup: {
      from: 'reviews',
      localField: '_id',
      foreignField: 'listings_id',
      as: 'comments'
    }
  },
  {
    $project: {
      _id: 1,
      title: 1,
      comments: '$reviews'
    }
  }
]);

// db.listings.aggregate([
//     {$lookup: {from: 'reviews',localField: '_id',foreignField: 'property_id',as: 'reviews'} },
//     {$group: {_id: {id: '$id',title: '$title', owner: '$owner'}, average_rating: { $avg: '$reviews.rating' }  }  },
//     {$sort: {average_rating: -1}},
//     {$limit: 1},
//     {$project: {_id: 0,  title: '$_id.title',owner: '$_id.owner',average_rating: 1   }  }]);
  