
use('test');

Show collections;